#line 1 "/Users/azozzalfras/Desktop/Tweaks/iCameraX/iCameraX/iCameraX.xm"









#include <objc/message.h>
#if defined(__clang__)
#if __has_feature(objc_arc)
#define _LOGOS_SELF_TYPE_NORMAL __unsafe_unretained
#define _LOGOS_SELF_TYPE_INIT __attribute__((ns_consumed))
#define _LOGOS_SELF_CONST const
#define _LOGOS_RETURN_RETAINED __attribute__((ns_returns_retained))
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif
#else
#define _LOGOS_SELF_TYPE_NORMAL
#define _LOGOS_SELF_TYPE_INIT
#define _LOGOS_SELF_CONST
#define _LOGOS_RETURN_RETAINED
#endif

__attribute__((unused)) static void _logos_register_hook$(Class _class, SEL _cmd, IMP _new, IMP *_old) {
unsigned int _count, _i;
Class _searchedClass = _class;
Method *_methods;
while (_searchedClass) {
_methods = class_copyMethodList(_searchedClass, &_count);
for (_i = 0; _i < _count; _i++) {
if (method_getName(_methods[_i]) == _cmd) {
if (_class == _searchedClass) {
*_old = method_getImplementation(_methods[_i]);
*_old = method_setImplementation(_methods[_i], _new);
} else {
class_addMethod(_class, _cmd, _new, method_getTypeEncoding(_methods[_i]));
}
free(_methods);
return;
}
}
free(_methods);
_searchedClass = class_getSuperclass(_searchedClass);
}
}
@class CAMViewFinderViewController; @class AVCaptureDeviceFormat; @class CAMHDRButton; @class CAMCaptureConfiguration; @class CAMBottomBar; @class CAMTopBar; @class CAMStillImageCaptureRequest; @class CAMViewfinderViewController; @class CAMVideoHDRCommand; @class CAMCaptureCapabilitiesHDRSupported; @class CAMUserPreferences; @class AVCapturePhotoSettings; @class CAMTorchPattern; @class CAMCaptureCapabilities; 
static Class _logos_superclass$_ungrouped$CAMCaptureCapabilities; static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackDualSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontTelephotoSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackTelephotoSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static double (*_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontDualPhotoModeMaximumZoomFactor)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static double (*_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontDualCameraSwitchOverZoomFactor)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static double (*_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontPhotoModeMaximumZoomFactor)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontPortraitModeSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackPortraitModeSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontIrisSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isModernHDRSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isPreviewDuringHDRSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontHDROnSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontHDRSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackIrisSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMTorchPattern; static CAMTorchPattern*  _LOGOS_RETURN_RETAINED(*_logos_orig$_ungrouped$CAMTorchPattern$initWithType$)(_LOGOS_SELF_TYPE_INIT CAMTorchPattern*, SEL, long long);static Class _logos_superclass$_ungrouped$AVCaptureDeviceFormat; static bool (*_logos_orig$_ungrouped$AVCaptureDeviceFormat$isIrisSupported)(_LOGOS_SELF_TYPE_NORMAL AVCaptureDeviceFormat* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMUserPreferences; static bool (*_logos_orig$_ungrouped$CAMUserPreferences$shouldResetCaptureConfiguration)(_LOGOS_SELF_TYPE_NORMAL CAMUserPreferences* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMUserPreferences$shouldCaptureHDREVO)(_LOGOS_SELF_TYPE_NORMAL CAMUserPreferences* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMCaptureConfiguration; static long long (*_logos_orig$_ungrouped$CAMCaptureConfiguration$mode)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST, SEL);static long long (*_logos_orig$_ungrouped$CAMCaptureConfiguration$device)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST, SEL);static long long (*_logos_orig$_ungrouped$CAMCaptureConfiguration$HDRMode)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMViewfinderViewController; static long long (*_logos_orig$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$)(_LOGOS_SELF_TYPE_NORMAL CAMViewfinderViewController* _LOGOS_SELF_CONST, SEL, long long);static bool (*_logos_orig$_ungrouped$CAMViewfinderViewController$_shouldUseZoomButtonForTelephotoToggleForCurrentModeAndDevice)(_LOGOS_SELF_TYPE_NORMAL CAMViewfinderViewController* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMTopBar; static long long (*_logos_orig$_ungrouped$CAMTopBar$backgroundStyle)(_LOGOS_SELF_TYPE_NORMAL CAMTopBar* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMBottomBar; static long long (*_logos_orig$_ungrouped$CAMBottomBar$backgroundStyle)(_LOGOS_SELF_TYPE_NORMAL CAMBottomBar* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMStillImageCaptureRequest; static long long (*_logos_orig$_ungrouped$CAMStillImageCaptureRequest$hdrMode)(_LOGOS_SELF_TYPE_NORMAL CAMStillImageCaptureRequest* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$AVCapturePhotoSettings; static unsigned int (*_logos_orig$_ungrouped$AVCapturePhotoSettings$shutterSound)(_LOGOS_SELF_TYPE_NORMAL AVCapturePhotoSettings* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMCaptureCapabilitiesHDRSupported; static bool (*_logos_orig$_ungrouped$CAMCaptureCapabilitiesHDRSupported$isFrontAutomaticHDRSupported)(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilitiesHDRSupported* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMVideoHDRCommand; static bool (*_logos_orig$_ungrouped$CAMVideoHDRCommand$_isEnabled)(_LOGOS_SELF_TYPE_NORMAL CAMVideoHDRCommand* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMHDRButton; static bool (*_logos_orig$_ungrouped$CAMHDRButton$allowsAutomaticHDR)(_LOGOS_SELF_TYPE_NORMAL CAMHDRButton* _LOGOS_SELF_CONST, SEL);static bool (*_logos_orig$_ungrouped$CAMHDRButton$allowsHDROn)(_LOGOS_SELF_TYPE_NORMAL CAMHDRButton* _LOGOS_SELF_CONST, SEL);static Class _logos_superclass$_ungrouped$CAMViewFinderViewController; static bool (*_logos_orig$_ungrouped$CAMViewFinderViewController$shouldAutorotate)(_LOGOS_SELF_TYPE_NORMAL CAMViewFinderViewController* _LOGOS_SELF_CONST, SEL);

#line 9 "/Users/azozzalfras/Desktop/Tweaks/iCameraX/iCameraX/iCameraX.xm"

static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isBackDualSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}




static CAMTorchPattern* _logos_method$_ungrouped$CAMTorchPattern$initWithType$(_LOGOS_SELF_TYPE_INIT CAMTorchPattern* __unused self, SEL __unused _cmd, long long arg1) _LOGOS_RETURN_RETAINED{
return (_logos_orig$_ungrouped$CAMTorchPattern$initWithType$ ? _logos_orig$_ungrouped$CAMTorchPattern$initWithType$ : (__typeof__(_logos_orig$_ungrouped$CAMTorchPattern$initWithType$))class_getMethodImplementation(_logos_superclass$_ungrouped$CAMTorchPattern, @selector(initWithType:)))(self, _cmd, 4);
}



static bool _logos_method$_ungrouped$AVCaptureDeviceFormat$isIrisSupported(_LOGOS_SELF_TYPE_NORMAL AVCaptureDeviceFormat* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}




static bool _logos_method$_ungrouped$CAMUserPreferences$shouldResetCaptureConfiguration(_LOGOS_SELF_TYPE_NORMAL CAMUserPreferences* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static long long _logos_method$_ungrouped$CAMCaptureConfiguration$mode(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 0;
}




static long long _logos_method$_ungrouped$CAMCaptureConfiguration$device(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 0;
}




static long long _logos_method$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$(_LOGOS_SELF_TYPE_NORMAL CAMViewfinderViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd, long long arg1) {
return 1;
(_logos_orig$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$ ? _logos_orig$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$ : (__typeof__(_logos_orig$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$))class_getMethodImplementation(_logos_superclass$_ungrouped$CAMViewfinderViewController, @selector(_aspectRatioForMode:)))(self, _cmd, arg1);
}



static long long _logos_method$_ungrouped$CAMTopBar$backgroundStyle(_LOGOS_SELF_TYPE_NORMAL CAMTopBar* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 1;
}



static long long _logos_method$_ungrouped$CAMBottomBar$backgroundStyle(_LOGOS_SELF_TYPE_NORMAL CAMBottomBar* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 1;
}




static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isFrontTelephotoSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isBackTelephotoSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static double _logos_method$_ungrouped$CAMCaptureCapabilities$_frontDualPhotoModeMaximumZoomFactor(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 5;
}



static double _logos_method$_ungrouped$CAMCaptureCapabilities$_frontDualCameraSwitchOverZoomFactor(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 5;
}




static double _logos_method$_ungrouped$CAMCaptureCapabilities$_frontPhotoModeMaximumZoomFactor(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 5;
}



static bool _logos_method$_ungrouped$CAMViewfinderViewController$_shouldUseZoomButtonForTelephotoToggleForCurrentModeAndDevice(_LOGOS_SELF_TYPE_NORMAL CAMViewfinderViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isFrontPortraitModeSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return FALSE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isBackPortraitModeSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return FALSE;
}




static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isFrontIrisSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}





static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isModernHDRSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {

return TRUE;

}







static bool _logos_method$_ungrouped$CAMUserPreferences$shouldCaptureHDREVO(_LOGOS_SELF_TYPE_NORMAL CAMUserPreferences* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {

return FALSE;

}







static long long _logos_method$_ungrouped$CAMCaptureConfiguration$HDRMode(_LOGOS_SELF_TYPE_NORMAL CAMCaptureConfiguration* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {

return 1;

}






static long long _logos_method$_ungrouped$CAMStillImageCaptureRequest$hdrMode(_LOGOS_SELF_TYPE_NORMAL CAMStillImageCaptureRequest* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {

return 1;

}





static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isPreviewDuringHDRSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {

return TRUE;

}





static unsigned int _logos_method$_ungrouped$AVCapturePhotoSettings$shutterSound(_LOGOS_SELF_TYPE_NORMAL AVCapturePhotoSettings* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return 0;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilitiesHDRSupported$isFrontAutomaticHDRSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilitiesHDRSupported* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isFrontHDROnSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isFrontHDRSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMVideoHDRCommand$_isEnabled(_LOGOS_SELF_TYPE_NORMAL CAMVideoHDRCommand* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}




static bool _logos_method$_ungrouped$CAMHDRButton$allowsAutomaticHDR(_LOGOS_SELF_TYPE_NORMAL CAMHDRButton* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMHDRButton$allowsHDROn(_LOGOS_SELF_TYPE_NORMAL CAMHDRButton* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}



static bool _logos_method$_ungrouped$CAMViewFinderViewController$shouldAutorotate(_LOGOS_SELF_TYPE_NORMAL CAMViewFinderViewController* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return FALSE;
}



static bool _logos_method$_ungrouped$CAMCaptureCapabilities$isBackIrisSupported(_LOGOS_SELF_TYPE_NORMAL CAMCaptureCapabilities* _LOGOS_SELF_CONST __unused self, SEL __unused _cmd) {
return TRUE;
}

static __attribute__((constructor)) void _logosLocalInit() {
{Class _logos_class$_ungrouped$CAMCaptureCapabilities = objc_getClass("CAMCaptureCapabilities"); _logos_superclass$_ungrouped$CAMCaptureCapabilities = class_getSuperclass(_logos_class$_ungrouped$CAMCaptureCapabilities); { _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isBackDualSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isBackDualSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackDualSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isFrontTelephotoSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isFrontTelephotoSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontTelephotoSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isBackTelephotoSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isBackTelephotoSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackTelephotoSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(_frontDualPhotoModeMaximumZoomFactor), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$_frontDualPhotoModeMaximumZoomFactor, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontDualPhotoModeMaximumZoomFactor);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(_frontDualCameraSwitchOverZoomFactor), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$_frontDualCameraSwitchOverZoomFactor, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontDualCameraSwitchOverZoomFactor);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(_frontPhotoModeMaximumZoomFactor), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$_frontPhotoModeMaximumZoomFactor, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$_frontPhotoModeMaximumZoomFactor);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isFrontPortraitModeSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isFrontPortraitModeSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontPortraitModeSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isBackPortraitModeSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isBackPortraitModeSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackPortraitModeSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isFrontIrisSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isFrontIrisSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontIrisSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isModernHDRSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isModernHDRSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isModernHDRSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isPreviewDuringHDRSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isPreviewDuringHDRSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isPreviewDuringHDRSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isFrontHDROnSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isFrontHDROnSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontHDROnSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isFrontHDRSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isFrontHDRSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isFrontHDRSupported);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilities, @selector(isBackIrisSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilities$isBackIrisSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilities$isBackIrisSupported);}Class _logos_class$_ungrouped$CAMTorchPattern = objc_getClass("CAMTorchPattern"); _logos_superclass$_ungrouped$CAMTorchPattern = class_getSuperclass(_logos_class$_ungrouped$CAMTorchPattern); { _logos_register_hook$(_logos_class$_ungrouped$CAMTorchPattern, @selector(initWithType:), (IMP)&_logos_method$_ungrouped$CAMTorchPattern$initWithType$, (IMP *)&_logos_orig$_ungrouped$CAMTorchPattern$initWithType$);}Class _logos_class$_ungrouped$AVCaptureDeviceFormat = objc_getClass("AVCaptureDeviceFormat"); _logos_superclass$_ungrouped$AVCaptureDeviceFormat = class_getSuperclass(_logos_class$_ungrouped$AVCaptureDeviceFormat); { _logos_register_hook$(_logos_class$_ungrouped$AVCaptureDeviceFormat, @selector(isIrisSupported), (IMP)&_logos_method$_ungrouped$AVCaptureDeviceFormat$isIrisSupported, (IMP *)&_logos_orig$_ungrouped$AVCaptureDeviceFormat$isIrisSupported);}Class _logos_class$_ungrouped$CAMUserPreferences = objc_getClass("CAMUserPreferences"); _logos_superclass$_ungrouped$CAMUserPreferences = class_getSuperclass(_logos_class$_ungrouped$CAMUserPreferences); { _logos_register_hook$(_logos_class$_ungrouped$CAMUserPreferences, @selector(shouldResetCaptureConfiguration), (IMP)&_logos_method$_ungrouped$CAMUserPreferences$shouldResetCaptureConfiguration, (IMP *)&_logos_orig$_ungrouped$CAMUserPreferences$shouldResetCaptureConfiguration);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMUserPreferences, @selector(shouldCaptureHDREVO), (IMP)&_logos_method$_ungrouped$CAMUserPreferences$shouldCaptureHDREVO, (IMP *)&_logos_orig$_ungrouped$CAMUserPreferences$shouldCaptureHDREVO);}Class _logos_class$_ungrouped$CAMCaptureConfiguration = objc_getClass("CAMCaptureConfiguration"); _logos_superclass$_ungrouped$CAMCaptureConfiguration = class_getSuperclass(_logos_class$_ungrouped$CAMCaptureConfiguration); { _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureConfiguration, @selector(mode), (IMP)&_logos_method$_ungrouped$CAMCaptureConfiguration$mode, (IMP *)&_logos_orig$_ungrouped$CAMCaptureConfiguration$mode);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureConfiguration, @selector(device), (IMP)&_logos_method$_ungrouped$CAMCaptureConfiguration$device, (IMP *)&_logos_orig$_ungrouped$CAMCaptureConfiguration$device);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureConfiguration, @selector(HDRMode), (IMP)&_logos_method$_ungrouped$CAMCaptureConfiguration$HDRMode, (IMP *)&_logos_orig$_ungrouped$CAMCaptureConfiguration$HDRMode);}Class _logos_class$_ungrouped$CAMViewfinderViewController = objc_getClass("CAMViewfinderViewController"); _logos_superclass$_ungrouped$CAMViewfinderViewController = class_getSuperclass(_logos_class$_ungrouped$CAMViewfinderViewController); { _logos_register_hook$(_logos_class$_ungrouped$CAMViewfinderViewController, @selector(_aspectRatioForMode:), (IMP)&_logos_method$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$, (IMP *)&_logos_orig$_ungrouped$CAMViewfinderViewController$_aspectRatioForMode$);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMViewfinderViewController, @selector(_shouldUseZoomButtonForTelephotoToggleForCurrentModeAndDevice), (IMP)&_logos_method$_ungrouped$CAMViewfinderViewController$_shouldUseZoomButtonForTelephotoToggleForCurrentModeAndDevice, (IMP *)&_logos_orig$_ungrouped$CAMViewfinderViewController$_shouldUseZoomButtonForTelephotoToggleForCurrentModeAndDevice);}Class _logos_class$_ungrouped$CAMTopBar = objc_getClass("CAMTopBar"); _logos_superclass$_ungrouped$CAMTopBar = class_getSuperclass(_logos_class$_ungrouped$CAMTopBar); { _logos_register_hook$(_logos_class$_ungrouped$CAMTopBar, @selector(backgroundStyle), (IMP)&_logos_method$_ungrouped$CAMTopBar$backgroundStyle, (IMP *)&_logos_orig$_ungrouped$CAMTopBar$backgroundStyle);}Class _logos_class$_ungrouped$CAMBottomBar = objc_getClass("CAMBottomBar"); _logos_superclass$_ungrouped$CAMBottomBar = class_getSuperclass(_logos_class$_ungrouped$CAMBottomBar); { _logos_register_hook$(_logos_class$_ungrouped$CAMBottomBar, @selector(backgroundStyle), (IMP)&_logos_method$_ungrouped$CAMBottomBar$backgroundStyle, (IMP *)&_logos_orig$_ungrouped$CAMBottomBar$backgroundStyle);}Class _logos_class$_ungrouped$CAMStillImageCaptureRequest = objc_getClass("CAMStillImageCaptureRequest"); _logos_superclass$_ungrouped$CAMStillImageCaptureRequest = class_getSuperclass(_logos_class$_ungrouped$CAMStillImageCaptureRequest); { _logos_register_hook$(_logos_class$_ungrouped$CAMStillImageCaptureRequest, @selector(hdrMode), (IMP)&_logos_method$_ungrouped$CAMStillImageCaptureRequest$hdrMode, (IMP *)&_logos_orig$_ungrouped$CAMStillImageCaptureRequest$hdrMode);}Class _logos_class$_ungrouped$AVCapturePhotoSettings = objc_getClass("AVCapturePhotoSettings"); _logos_superclass$_ungrouped$AVCapturePhotoSettings = class_getSuperclass(_logos_class$_ungrouped$AVCapturePhotoSettings); { _logos_register_hook$(_logos_class$_ungrouped$AVCapturePhotoSettings, @selector(shutterSound), (IMP)&_logos_method$_ungrouped$AVCapturePhotoSettings$shutterSound, (IMP *)&_logos_orig$_ungrouped$AVCapturePhotoSettings$shutterSound);}Class _logos_class$_ungrouped$CAMCaptureCapabilitiesHDRSupported = objc_getClass("CAMCaptureCapabilitiesHDRSupported"); _logos_superclass$_ungrouped$CAMCaptureCapabilitiesHDRSupported = class_getSuperclass(_logos_class$_ungrouped$CAMCaptureCapabilitiesHDRSupported); { _logos_register_hook$(_logos_class$_ungrouped$CAMCaptureCapabilitiesHDRSupported, @selector(isFrontAutomaticHDRSupported), (IMP)&_logos_method$_ungrouped$CAMCaptureCapabilitiesHDRSupported$isFrontAutomaticHDRSupported, (IMP *)&_logos_orig$_ungrouped$CAMCaptureCapabilitiesHDRSupported$isFrontAutomaticHDRSupported);}Class _logos_class$_ungrouped$CAMVideoHDRCommand = objc_getClass("CAMVideoHDRCommand"); _logos_superclass$_ungrouped$CAMVideoHDRCommand = class_getSuperclass(_logos_class$_ungrouped$CAMVideoHDRCommand); { _logos_register_hook$(_logos_class$_ungrouped$CAMVideoHDRCommand, @selector(_isEnabled), (IMP)&_logos_method$_ungrouped$CAMVideoHDRCommand$_isEnabled, (IMP *)&_logos_orig$_ungrouped$CAMVideoHDRCommand$_isEnabled);}Class _logos_class$_ungrouped$CAMHDRButton = objc_getClass("CAMHDRButton"); _logos_superclass$_ungrouped$CAMHDRButton = class_getSuperclass(_logos_class$_ungrouped$CAMHDRButton); { _logos_register_hook$(_logos_class$_ungrouped$CAMHDRButton, @selector(allowsAutomaticHDR), (IMP)&_logos_method$_ungrouped$CAMHDRButton$allowsAutomaticHDR, (IMP *)&_logos_orig$_ungrouped$CAMHDRButton$allowsAutomaticHDR);}{ _logos_register_hook$(_logos_class$_ungrouped$CAMHDRButton, @selector(allowsHDROn), (IMP)&_logos_method$_ungrouped$CAMHDRButton$allowsHDROn, (IMP *)&_logos_orig$_ungrouped$CAMHDRButton$allowsHDROn);}Class _logos_class$_ungrouped$CAMViewFinderViewController = objc_getClass("CAMViewFinderViewController"); _logos_superclass$_ungrouped$CAMViewFinderViewController = class_getSuperclass(_logos_class$_ungrouped$CAMViewFinderViewController); { _logos_register_hook$(_logos_class$_ungrouped$CAMViewFinderViewController, @selector(shouldAutorotate), (IMP)&_logos_method$_ungrouped$CAMViewFinderViewController$shouldAutorotate, (IMP *)&_logos_orig$_ungrouped$CAMViewFinderViewController$shouldAutorotate);}} }
#line 236 "/Users/azozzalfras/Desktop/Tweaks/iCameraX/iCameraX/iCameraX.xm"
